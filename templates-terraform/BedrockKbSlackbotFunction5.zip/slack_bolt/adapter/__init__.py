"""Adapter modules for running Bolt apps along with Web frameworks or Socket Mode.
"""
